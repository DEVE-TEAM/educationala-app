package com.example.android.educationalapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.String;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button finalResult = (Button) findViewById(R.id.final_Result_B);

        finalResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup rG1 = (RadioGroup) findViewById(R.id.rG_1);
                RadioGroup rG2 = (RadioGroup) findViewById(R.id.R_G_2);
                RadioGroup rG3 = (RadioGroup) findViewById(R.id.R_G_3);
                RadioGroup rG4 = (RadioGroup) findViewById(R.id.R_G_4);
                RadioGroup rG5 = (RadioGroup) findViewById(R.id.R_G_5);
                RadioGroup rG6 = (RadioGroup) findViewById(R.id.R_G_6);

                RadioButton q1 = (RadioButton) findViewById(R.id.q1o1);
                RadioButton q2 = (RadioButton) findViewById(R.id.q2o2);
                RadioButton q3 = (RadioButton) findViewById(R.id.q3o1);
                RadioButton q4 = (RadioButton) findViewById(R.id.q4o3);
                RadioButton q5 = (RadioButton) findViewById(R.id.q5o1);
                RadioButton q6 = (RadioButton) findViewById(R.id.q6o2);

                CheckBox q7 = (CheckBox) findViewById(R.id.q7O1);
                CheckBox q71 = (CheckBox) findViewById(R.id.q7O2);
                CheckBox q72 = (CheckBox) findViewById(R.id.q7O5);

                CheckBox q73 = (CheckBox) findViewById(R.id.q7O3);
                CheckBox q74 = (CheckBox) findViewById(R.id.q7O4);

                RadioButton correctRg1 = (RadioButton) findViewById(rG1.getCheckedRadioButtonId());
                RadioButton correctRg2 = (RadioButton) findViewById(rG2.getCheckedRadioButtonId());
                RadioButton correctRg3 = (RadioButton) findViewById(rG3.getCheckedRadioButtonId());
                RadioButton correctRg4 = (RadioButton) findViewById(rG4.getCheckedRadioButtonId());
                RadioButton correctRg5 = (RadioButton) findViewById(rG5.getCheckedRadioButtonId());
                RadioButton correctRg6 = (RadioButton) findViewById(rG6.getCheckedRadioButtonId());

                EditText Name = (EditText) findViewById(R.id.name_description_view);
                String Namee = Name.getText().toString();

                EditText answer = (EditText) findViewById(R.id.answer_view);
                String q8 = answer.getText().toString();
                String correctAnswer = "Virtual Private Network";


                int grade = 0;
                if (correctRg1 == q1) {
                    grade++;
                }
                if (correctRg2 == q2) {
                    grade++;
                }
                if (correctRg3 == q3) {
                    grade++;
                }
                if (correctRg4 == q4) {
                    grade++;
                }
                if (correctRg5 == q5) {
                    grade++;
                }
                if (correctRg6 == q6) {
                    grade++;
                }
                if (q73.isChecked() || q74.isChecked()) {

                } else if (q7.isChecked() && q71.isChecked() && q72.isChecked()) {
                    grade++;
                }
                if (q8.equals(correctAnswer)) {
                    grade++;

                }
                Toast.makeText(MainActivity.this, "name is :" + Namee + "\n Your Score is: " + grade, Toast.LENGTH_LONG).show();
                grade = 0;
            }


        });


        {

        }
    }
}








